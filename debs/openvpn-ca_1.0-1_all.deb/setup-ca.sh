#!/bin/bash
set -e

echo "[INFO] Initializing CA with Easy-RSA..."

install -d -m 0755 /etc/openvpn/easy-rsa/
install -m 0644 /usr/share/easy-rsa/* /etc/openvpn/easy-rsa/

cd /etc/openvpn/easy-rsa/
./easyrsa init-pki
./easyrsa build-ca nopass

echo "[INFO] CA certificate created at /etc/openvpn/easy-rsa/pki/ca.crt"
