# Обзор конфигурации мониторинга

## Prometheus

- Сбор метрик осуществляется с:
  - another-vm: node_exporter, openvpn_exporter, Prometheus
  - rescue-vm: node_exporter
- Конфигурационный файл: `prometheus.yml`
- Правила оповещений загружаются из `/etc/prometheus/alert.rules.yml`

## Правила оповещений (Alert Rules)

- Определены в `alert.rules.yml`
- Включают:
  - HighLoad — высокая нагрузка на хост
  - VPNServerDown — недоступность VPN-сервера
  - OpenVPNExporterDown — сбой экспортера метрик
  - NoVPNClients — отсутствие активных клиентов
  - DiskAlmostFull — переполнение диска
  - PrometheusNotScraping — сбой сбора метрик
- Проверены через `amtool check-config`

## Alertmanager

- Конфигурационный файл: `alertmanager.yml`
- Настроен маршрут по умолчанию (`default`)
- Уведомления отправляются по email или webhook
- Пароль не хранится в конфигурации — используется переменная окружения `SMTP_PASSWORD`
- Пример генерации финального файла:
  ```bash
  export SMTP_PASSWORD='ваш_пароль'
  envsubst < alertmanager.yml.template > alertmanager.yml
